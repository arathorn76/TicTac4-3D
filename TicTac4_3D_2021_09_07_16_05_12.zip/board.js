class Board {
  constructor(xsize, ysize, zsize, cellsize) {
    this.xsize = xsize;
    this.ysize = ysize;
    this.zsize = zsize;
    this.cellsize = cellsize;
    this.activePlayer = 1;

    this.cells = [];

    for (var k = 0; k < this.zsize; k++) {
      this.cells[k] = [];

      for (var i = 0; i < this.ysize; i++) {
        this.cells[k][i] = [];

        for (var j = 0; j < this.xsize; j++) {
          this.cells[k][i][j] = new Cell(
            i * this.cellsize,
            j * this.cellsize,
            k * this.cellsize,
            this.cellsize
          );
        }
      }
    }
  }

  show() {
    for (var i = 0; i < this.ysize; i++) {
      for (var j = 0; j < this.xsize; j++) {
        for (var k = 0; k < this.zsize; k++) {
          this.cells[i][j][k].show();
        }
      }
    }
  }
}
