class Cell{
  constructor(x,y,z,size){
    this.x = x;
    this.y = y;
    this.z = z;
    this.size = size;
    this.state = 0;
  }
  
  show(){
    if(this.state === 1){
      fill(255,100,100,100);
    } else if(this.state === 2){
      fill(100,255,100,100);
    }else{
      fill(255,255,255,100);
    }
      
    //rect(this.x , this.y , this.size);
    push();
    rotateX(1);
    rotateY(1);
    //rotateZ(1);
    translate(this.x, this.y, this.z);
    box(this.size);
    pop();
  }
  
  play(player){
    if(this.state === 0){
      this.state = player;
    }else{
      console.log("invalid move");
    }
  }
}