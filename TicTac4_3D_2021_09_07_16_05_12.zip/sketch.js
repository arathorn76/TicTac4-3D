var board;

function setup() {
  createCanvas(400, 400, WEBGL);
  board = new Board(3, 3, 3, 40);
  background(80);
}

function draw() {
  board.show();
}
